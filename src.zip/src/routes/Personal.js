const Personal = () => {
    return <body>Personal page content</body>;
};

export default Personal;