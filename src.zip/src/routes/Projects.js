const Projects = () => {
    return <body>Projects page content</body>;
};

export default Projects;