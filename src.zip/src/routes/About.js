const Home = () => {
    return <body>About page content</body>;
};

export default Home;