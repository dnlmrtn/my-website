export const menuItems = [
    {
        title: 'Home       ',
        url: '/home',
    },
    {
        title: 'About Me',
        url: '/about',
    },
    {
        title: '05.08.2023',
        url: 'https://github.com/dnlmrtn/my-website',
    },
    {
        title: 'Projects',
        url: '/projects',
    },
    {
        title: 'Personal',
        url: '/personal',
    },
];
